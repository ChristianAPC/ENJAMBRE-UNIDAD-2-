let agentes = [];   
let radio = 75;     

function setup() {
  createCanvas(400, 400);
  randomSeed(22);   

  for (let i = 0; i < 21; i++) {   
    agentes.push(crearAgente());
  }
}

function draw() {
  background(245, 243, 235);

  for (let a of agentes) {
    let vecinos = vecinosDe(a, agentes, radio);
    acercarAlPromedio(a, vecinos);
    mover(a);
    aplicarBorde(a);
  }
  for (let a of agentes) {
    mostrarConexiones(a, vecinosDe(a, agentes, radio));
  }
  for (let a of agentes) {
    mostrar(a, vecinosDe(a, agentes, radio).length);
  }
}
function crearAgente() {
  let a = {
    x: random(40, 360),
    y: random(40, 360),
    vx: random(-2.4, 2.4),
    vy: random(-2.4, 2.4),
    d: 14
  };
  a.rapidez = sqrt(a.vx * a.vx + a.vy * a.vy);
  return a;
}

function esVecino(a, b, r) {
  if (a === b) return false;          
  let dx = b.x - a.x;
  let dy = b.y - a.y;
  let distancia = sqrt(dx * dx + dy * dy);
  return distancia < r;
}

function vecinosDe(a, todos, r) {
  let vs = [];
  for (let b of todos) {
    if (esVecino(a, b, r)) vs.push(b);
  }
  return vs;
}
function acercarAlPromedio(a, vecinos) {
  if (vecinos.length === 0) return;
  let cantidad = 0.05;   
  let sumaVx = 0;
  let sumaVy = 0;
  for (let b of vecinos) {
    sumaVx += b.vx;
    sumaVy += b.vy;
  }
  let promVx = sumaVx / vecinos.length;
  let promVy = sumaVy / vecinos.length;
  a.vx = lerp(a.vx, promVx, cantidad);
  a.vy = lerp(a.vy, promVy, cantidad);
  let v = sqrt(a.vx * a.vx + a.vy * a.vy);
  if (v > 0) {
    a.vx = a.vx / v * a.rapidez;
    a.vy = a.vy / v * a.rapidez;
  }
}
function mover(a) {
  a.x += a.vx;
  a.y += a.vy;
}
function aplicarBorde(a) {
let rebote = -1;
let r = a.d / 2;
  if (a.x > width - r) {
    a.x = width - r;
    a.vx *= rebote;
  }
  if (a.x < r) {
    a.x = r;
    a.vx *= rebote;
  }
  if (a.y > height - r) {
    a.y = height - r;
    a.vy *= rebote;
  }
  if (a.y < r) {
    a.y = r;
    a.vy *= rebote;
  }
}
function mostrarConexiones(a, vecinos) {
  stroke(46, 196, 230, 90);
  strokeWeight(1);
  for (let b of vecinos) {
    line(a.x, a.y, b.x, b.y);
  }
}
function mostrarRadioMouse() {
  noFill();
  stroke(230, 120, 60);
  strokeWeight(1.5);
  circle(mouseX, mouseY, radio * 2);   
}
function mostrar(a, cantidadVecinos) {
  let mouse = { x: mouseX, y: mouseY };
  if (esVecino(mouse, a, radio)) {
    stroke(40);
    strokeWeight(2);
  } else {
    noStroke();
  }
  if (cantidadVecinos > 0) {
    fill(255, 0,0 );
  } else {
    fill(300);
  }
  circle(a.x, a.y, a.d);
} 